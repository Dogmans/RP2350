#include "LCD_test.h"  //example


int main(void)
{
    LCD_1in28_LVGL_Test();

    return 0;
}
